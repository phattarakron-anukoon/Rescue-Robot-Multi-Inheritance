public interface Communicable {

    void send(String message);
    String getDeviceId();
}